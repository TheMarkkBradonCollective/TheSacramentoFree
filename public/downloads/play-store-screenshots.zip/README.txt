SacramentoBuyNothing — Google Play listing graphics

Fictional demo neighbors only. Do not upload live member photos.

Play Console → Store presence → Main store listing

Store icon (512×512, 32-bit PNG — website masthead lockup):
  icon-512.png

Feature graphic (1024×500):
  feature-graphic-1024x500.png

Phone screenshots (1080×1920) — upload in this order:
  1. 01-home.png — Public newspaper home
  2. 02-feed.png — Feed — neighbor social posts
  3. 03-stuff.png — Stuff — giveaways and requests
  4. 04-listing.png — Listing detail
  5. 05-map.png — Neighborhood map
  6. 06-events.png — Community events
  7. 07-event.png — Event detail
  8. 08-messages.png — Messages

Go Get pickup screenshots are in a separate zip (director download).
