SacramentoBuyNothing — Google Play listing graphics

Fictional demo neighbors only. Do not upload live member photos.

Play Console → Store presence → Main store listing

Store icon (512×512, 32-bit PNG — website masthead lockup):
  icon-512.png

Feature graphic (1024×500):
  feature-graphic-1024x500.png

Phone screenshots (1080×1920) — upload in this order:
  1. 01-home.png — Public newspaper home
  2. 02-stuff.png — Stuff listings
  3. 03-listing.png — Listing detail
  4. 04-map.png — Neighborhood map
  5. 05-events.png — Community events
  6. 06-event.png — Event detail
  7. 07-messages.png — Messages
  8. 08-account.png — Account / profile
