SacramentoBuyNothing — Google Play listing graphics

Fictional demo neighbors only. Do not upload live member photos.

Play Console → Store presence → Main store listing

Store icon (512×512, 32-bit PNG — website masthead lockup):
  icon-512.png

Feature graphic (1024×500):
  feature-graphic-1024x500.png

Phone screenshots (1080×1920) — upload in this order:
  1. 01-home.png — Public newspaper home
  2. 02-feed.png — Feed — neighbor social posts
  3. 03-stuff.png — Stuff — giveaways and requests
  4. 04-listing.png — Listing detail
  5. 05-map.png — Neighborhood map
  6. 06-events.png — Community events
  7. 07-event.png — Event detail
  8. 08-messages.png — Messages
  9. 09-goget-listing.png — Go Get — listing pickup route
  10. 10-goget-chat.png — Go Get — chat coordination
  11. 11-goget-ring.png — Go Get — incoming pickup ring
  12. 12-goget-waiting.png — Go Get — waiting for neighbor
  13. 13-goget-navigation.png — Go Get — turn-by-turn navigation
  14. 14-goget-tracking.png — Go Get — live ETA tracking
  15. 15-goget-meeting.png — Go Get — meetup map
  16. 16-goget-arrived.png — Go Get — arrival handoff

Go Get screenshots use fictional Sacramento landmarks (Capitol, Midtown, East Sac, etc.).
