SacramentoBuyNothing — Go Get pickup coordination screenshots

Fictional demo neighbors and Sacramento landmarks only (Capitol, Midtown, East Sac, etc.).
Do not upload live member photos.

Phone screenshots (1080×1920):
  1. 09-goget-listing.png — Listing pickup route
  2. 10-goget-chat.png — Chat coordination
  3. 11-goget-ring.png — Incoming pickup ring
  4. 12-goget-waiting.png — Waiting for neighbor
  5. 13-goget-navigation.png — Turn-by-turn navigation
  6. 14-goget-tracking.png — Live ETA tracking
  7. 15-goget-meeting.png — Meetup map
  8. 16-goget-arrived.png — Arrival handoff

Regenerate: npm run android:play-screenshots
